import React from 'react';
import { OrgMode, OrgProfile } from '../data/orgData';
import { CardCornerAccents, ZigzagDivider } from './Motifs';

interface StructureSectionProps {
  profile: OrgProfile;
  mode: OrgMode;
  onSelectUnit: (index: number) => void;
}

export function StructureSection({
  profile,
  mode,
  onSelectUnit,
}: StructureSectionProps) {
  const isOsis = mode === 'osis';
  const splitIndex = profile.units.length > 5 ? 4 : 3;
  const leftUnits = profile.units.slice(0, splitIndex);
  const rightUnits = profile.units.slice(splitIndex);

  const topCore = profile.core.slice(0, 3);
  const bottomCore = profile.core.slice(3);

  const nodeBase =
    'min-w-[116px] rounded-[10px] border border-slate-200 bg-white px-[18px] py-2.5 text-center text-[15px] text-slate-800';
  const nodeHighlight = isOsis
    ? 'min-w-[116px] rounded-[10px] border border-blue-700 bg-blue-700 px-[18px] py-2.5 text-center text-[15px] font-semibold text-white'
    : 'min-w-[116px] rounded-[10px] border border-red-600 bg-red-600 px-[18px] py-2.5 text-center text-[15px] font-semibold text-white';

  const tagColor = isOsis ? 'bg-blue-700 text-white' : 'bg-red-600 text-white';
  const avatarBg = isOsis ? 'bg-blue-50' : 'bg-red-50';

  return (
    <section id="sec-org" className="relative overflow-hidden border-t border-slate-200 bg-white py-16 sm:py-20">
      <div className="relative z-10 mx-auto max-w-[1240px] px-5 sm:px-7">
        {/* Centered Struktur Organisasi Title */}
        <div className="mb-8 text-center">
          <h2
            className={`font-display text-[clamp(26px,3.4vw,38px)] font-extrabold ${
              isOsis ? 'text-blue-700' : 'text-red-600'
            }`}
          >
            Struktur Organisasi
          </h2>
          <ZigzagDivider
            color={isOsis ? '#2563eb' : '#dc2626'}
            className="mt-3"
          />
        </div>

        {/* Original Vertical Tree */}
        <div className="flex flex-col items-center gap-2.5">
          {[
            { label: 'Kepala Sekolah', highlight: false },
            { label: 'Wakil Bidang Kesiswaan', highlight: false },
            { label: 'Pembina OSIS MPK', highlight: false },
            { label: 'Ketua Umum', highlight: true },
          ].map((node) => (
            <React.Fragment key={node.label}>
              <div className={node.highlight ? nodeHighlight : nodeBase}>
                {node.label}
              </div>
              <div className="h-5 w-0.5 bg-slate-200" aria-hidden="true" />
            </React.Fragment>
          ))}

          <div className="flex flex-wrap items-start justify-center gap-7">
            {[
              { title: 'Ketua 1', units: leftUnits, offset: 0 },
              { title: 'Ketua 2', units: rightUnits, offset: splitIndex },
            ].map((branch) => (
              <div key={branch.title} className="flex flex-col items-center">
                <div className={nodeHighlight}>{branch.title}</div>
                <div className="h-5 w-0.5 bg-slate-200" aria-hidden="true" />
                <div className="flex flex-wrap justify-center gap-2">
                  {branch.units.map((u, localIdx) => {
                    const unitIndex = branch.offset + localIdx;
                    return (
                      <button
                        key={u.code}
                        type="button"
                        onClick={() => onSelectUnit(unitIndex)}
                        className={`min-w-[116px] rounded-[10px] border border-slate-200 bg-white px-4 py-2.5 text-center text-[15px] text-slate-800 transition-colors hover:shadow-sm ${
                          isOsis ? 'hover:border-blue-600' : 'hover:border-red-600'
                        }`}
                      >
                        <div>
                          {profile.unitLabel} {u.code}
                        </div>
                        <small className="block text-[13px] text-slate-500">
                          {u.shortTitle}
                        </small>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Centered Pengurus Inti Title */}
        <div id="sec-inti" className="mt-14 mb-6 text-center">
          <h2
            className={`font-display text-[clamp(26px,3.4vw,38px)] font-extrabold ${
              isOsis ? 'text-blue-700' : 'text-red-600'
            }`}
          >
            Pengurus Inti
          </h2>
          <ZigzagDivider color="#f59e0b" className="mt-3" />
        </div>

        {/* 3-card row */}
        <div className="flex flex-wrap justify-center gap-4">
          {topCore.map((member) => (
            <div
              key={member.role}
              className="group relative w-[calc(50%-8px)] overflow-hidden rounded-[18px] border border-slate-200 bg-white p-[18px] shadow-[0_8px_24px_rgba(31,41,55,0.03)] sm:w-[208px]"
            >
              <CardCornerAccents leftColor={isOsis ? '#dbeafe' : '#fee2e2'} />
              <div className={`relative z-10 mb-3.5 aspect-square rounded-xl ${avatarBg}`} />
              <span
                className={`relative z-10 mb-2.5 inline-block rounded-[7px] px-3 py-1 text-[13px] font-bold ${tagColor}`}
              >
                {member.role}
              </span>
              <div className="relative z-10 font-display text-base font-extrabold text-slate-900">
                {member.name}
              </div>
            </div>
          ))}
        </div>

        <div className="h-[18px]" />

        {/* 4-card row */}
        <div className="flex flex-wrap justify-center gap-4">
          {bottomCore.map((member, idx) => (
            <div
              key={member.role}
              className="group relative w-[calc(50%-8px)] overflow-hidden rounded-[18px] border border-slate-200 bg-white p-[18px] shadow-[0_8px_24px_rgba(31,41,55,0.03)] sm:w-[208px]"
            >
              <CardCornerAccents
                leftColor={idx < 2 ? '#fef3c7' : isOsis ? '#ccfbf1' : '#fbcfe8'}
              />
              <div className={`relative z-10 mb-3.5 aspect-square rounded-xl ${avatarBg}`} />
              <span
                className={`relative z-10 mb-2.5 inline-block rounded-[7px] px-3 py-1 text-[13px] font-bold ${tagColor}`}
              >
                {member.role}
              </span>
              <div className="relative z-10 font-display text-base font-extrabold text-slate-900">
                {member.name}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
