import React from 'react';
import { OrgMode, OrgProfile } from '../data/orgData';
import { ZigzagDivider } from './Motifs';

interface AboutSectionProps {
  profile: OrgProfile;
  mode: OrgMode;
}

export function AboutSection({ profile, mode }: AboutSectionProps) {
  const isOsis = mode === 'osis';

  const singleHeaderColor = isOsis ? 'bg-blue-700' : 'bg-red-600';

  return (
    <section id="sec-about" className="relative overflow-hidden bg-white py-16 sm:py-20">
      <div className="relative z-10 mx-auto max-w-[1240px] px-5 sm:px-7">
        <div className="mb-8 text-center">
          <h2
            className={`font-display text-[clamp(26px,3.4vw,38px)] font-extrabold ${
              isOsis ? 'text-blue-700' : 'text-red-600'
            }`}
          >
            Tentang Kami
          </h2>
          <ZigzagDivider
            color={isOsis ? '#14b8a6' : '#f59e0b'}
            className="mt-3"
          />
        </div>

        {/* Stacked Visi & Misi cards with a single solid thin colored header bar on top */}
        <div className="grid gap-5">
          <div
            id="sec-visi"
            className="overflow-hidden rounded-[18px] border border-slate-200 bg-white text-center shadow-[0_8px_24px_rgba(31,41,55,0.03)]"
          >
            <div className={`h-2 w-full ${singleHeaderColor}`} aria-hidden="true" />
            <div className="p-7">
              <h3 className="mb-2 text-lg font-bold text-slate-900">Visi</h3>
              <p className="m-0 text-slate-600">{profile.visi}</p>
            </div>
          </div>

          <div
            id="sec-misi"
            className="overflow-hidden rounded-[18px] border border-slate-200 bg-white text-center shadow-[0_8px_24px_rgba(31,41,55,0.03)]"
          >
            <div className={`h-2 w-full ${singleHeaderColor}`} aria-hidden="true" />
            <div className="p-7">
              <h3 className="mb-2 text-lg font-bold text-slate-900">Misi</h3>
              <ul className="mx-auto my-2 list-inside list-disc space-y-2 text-slate-600">
                {profile.misi.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
