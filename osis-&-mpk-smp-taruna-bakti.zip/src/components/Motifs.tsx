import React, { useId } from 'react';
import { OrgMode } from '../data/orgData';

/**
 * Airy floating rotated heptagons in soft pastel tints
 * matching the clean, spacious hero background motif.
 */
export function HexNetworkPattern({ mode }: { mode: OrgMode }) {
  const isOsis = mode === 'osis';

  // Regular heptagon centered at (0,0) with radius 100
  const heptagon =
    '100,0 62.3,78.2 -22.3,97.5 -90.1,43.4 -90.1,-43.4 -22.3,-97.5 62.3,-78.2';

  const colors = isOsis
    ? {
        sky: '#bae6fd',
        mint: '#a7f3d0',
        periwinkle: '#c7d2fe',
        amber: '#fde68a',
      }
    : {
        sky: '#fecdd3',
        mint: '#fed7aa',
        periwinkle: '#fecaca',
        amber: '#fde68a',
      };

  return (
    <svg
      viewBox="0 0 1440 720"
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 h-full w-full"
      preserveAspectRatio="xMidYMid slice"
    >
      {/* Small top-left accent heptagon */}
      <g transform="translate(88 128) rotate(16) scale(0.68)" opacity="0.48">
        <polygon points={heptagon} fill={colors.sky} />
      </g>

      {/* Soft bottom-left heptagon */}
      <g transform="translate(310 615) rotate(-14) scale(0.95)" opacity="0.34">
        <polygon points={heptagon} fill={colors.periwinkle} />
      </g>

      {/* Upper-center airy heptagon */}
      <g transform="translate(620 115) rotate(24) scale(0.82)" opacity="0.32">
        <polygon points={heptagon} fill={colors.amber} />
      </g>

      {/* Paired small sky/rose + large mint/peach heptagons on right (from reference) */}
      <g transform="translate(855 225) rotate(12) scale(0.76)" opacity="0.55">
        <polygon points={heptagon} fill={colors.sky} />
      </g>

      <g transform="translate(1125 365) rotate(-8) scale(1.92)" opacity="0.46">
        <polygon points={heptagon} fill={colors.mint} />
      </g>

      {/* Subtle far-right accent heptagon */}
      <g transform="translate(1355 125) rotate(32) scale(0.72)" opacity="0.36">
        <polygon points={heptagon} fill={colors.periwinkle} />
      </g>
    </svg>
  );
}

/**
 * Sweeping convex bottom curve mask for the Hero banner (reference 1).
 */
export function HeroBottomCurve() {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 overflow-hidden leading-none">
      <svg
        viewBox="0 0 1440 110"
        preserveAspectRatio="none"
        className="block h-12 w-full sm:h-16 md:h-24"
        aria-hidden="true"
      >
        <path
          d="M0,16 C380,110 1060,110 1440,16 L1440,110 L0,110 Z"
          fill="#ffffff"
        />
      </svg>
    </div>
  );
}

/**
 * Top convex arch mask for the deep-colored Sekbid/Komisi showcase banner (reference 2).
 */
export function SectionTopArch({ fill }: { fill: string }) {
  return (
    <div className="pointer-events-none relative -mb-px w-full overflow-hidden leading-none">
      <svg
        viewBox="0 0 1440 92"
        preserveAspectRatio="none"
        className="block h-10 w-full sm:h-14 md:h-20"
        aria-hidden="true"
      >
        <path
          d="M0,92 C390,0 1050,0 1440,92 L1440,92 L0,92 Z"
          fill={fill}
        />
      </svg>
    </div>
  );
}

/**
 * Halftone dot-matrix backdrop inside the deep arched Bidang/Sekbid/Komisi banner (reference 2).
 */
export function HalftoneDotMatrix({ mode }: { mode: OrgMode }) {
  const uid = useId().replace(/:/g, '');
  const dotColor = mode === 'osis' ? '#93c5fd' : '#fca5a5';
  const contrastDot = '#fde68a';

  return (
    <svg
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 h-full w-full opacity-[0.18]"
      preserveAspectRatio="xMidYMid slice"
    >
      <defs>
        <pattern id={`halftone-${uid}`} width="22" height="22" patternUnits="userSpaceOnUse">
          <circle cx="5" cy="5" r="1.4" fill={dotColor} />
          <circle cx="16" cy="16" r="1.1" fill={contrastDot} fillOpacity="0.55" />
        </pattern>
        <radialGradient id={`halftone-mask-grad-${uid}`} cx="50%" cy="42%" r="62%">
          <stop offset="0%" stopColor="white" stopOpacity="0.25" />
          <stop offset="55%" stopColor="white" stopOpacity="0.95" />
          <stop offset="100%" stopColor="white" stopOpacity="0.1" />
        </radialGradient>
        <mask id={`halftone-mask-${uid}`}>
          <rect width="100%" height="100%" fill={`url(#halftone-mask-grad-${uid})`} />
        </mask>
      </defs>
      <rect width="100%" height="100%" fill={`url(#halftone-${uid})`} mask={`url(#halftone-mask-${uid})`} />
    </svg>
  );
}

/**
 * Crisp 5-peak zigzag chevron divider beneath section headings (references 1 & 2).
 */
export function ZigzagDivider({
  color,
  className = '',
}: {
  color?: string;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 64 12"
      fill="none"
      className={`mx-auto h-3 w-16 ${className}`}
      aria-hidden="true"
    >
      <polyline
        points="2,9 9,3 16,9 23,3 30,9 37,3 44,9 51,3 58,9"
        stroke={color || 'currentColor'}
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/**
 * Floating cluster of solid, polka-dot, and diagonal-hatched circles
 * anchored cleanly on section edges (inspired by reference 1).
 */
export function LayeredCircleCluster({
  side,
  mode,
}: {
  side: 'left' | 'right';
  mode: OrgMode;
}) {
  const uid = useId().replace(/:/g, '');
  const palette =
    mode === 'osis'
      ? {
          solidA: '#dbeafe',
          solidB: '#ccfbf1',
          dots: '#38bdf8',
          stripes: '#f59e0b',
          ring: '#93c5fd',
        }
      : {
          solidA: '#fee2e2',
          solidB: '#fef3c7',
          dots: '#fb7185',
          stripes: '#d97706',
          ring: '#fca5a5',
        };

  return (
    <svg
      viewBox="0 0 280 280"
      aria-hidden="true"
      className={`pointer-events-none hidden select-none lg:block absolute top-1/2 -translate-y-1/2 w-60 h-60 xl:w-72 xl:h-72 ${
        side === 'left' ? '-left-16 xl:-left-10' : '-right-16 xl:-right-10'
      }`}
    >
      <defs>
        <pattern id={`polka-${uid}`} width="11" height="11" patternUnits="userSpaceOnUse">
          <circle cx="3.5" cy="3.5" r="1.6" fill={palette.dots} fillOpacity="0.45" />
        </pattern>
        <pattern
          id={`diag-${uid}`}
          width="10"
          height="10"
          patternTransform="rotate(42 0 0)"
          patternUnits="userSpaceOnUse"
        >
          <line x1="0" y1="0" x2="0" y2="10" stroke={palette.stripes} strokeWidth="2.4" strokeOpacity="0.32" />
        </pattern>
      </defs>

      {side === 'left' ? (
        <>
          <circle cx="96" cy="112" r="64" fill={palette.solidA} fillOpacity="0.72" />
          <circle cx="152" cy="148" r="52" fill={palette.solidB} fillOpacity="0.75" />
          <circle cx="88" cy="186" r="46" fill={`url(#diag-${uid})`} />
          <circle cx="156" cy="84" r="36" fill={`url(#polka-${uid})`} />
          <circle cx="198" cy="192" r="48" fill={`url(#polka-${uid})`} />
          <circle cx="64" cy="70" r="22" fill="none" stroke={palette.ring} strokeWidth="1.5" strokeOpacity="0.55" />
        </>
      ) : (
        <>
          <circle cx="182" cy="126" r="64" fill={palette.solidA} fillOpacity="0.72" />
          <circle cx="126" cy="96" r="48" fill={palette.solidB} fillOpacity="0.78" />
          <circle cx="132" cy="188" r="44" fill={`url(#diag-${uid})`} />
          <circle cx="218" cy="64" r="28" fill={palette.solidB} fillOpacity="0.85" />
          <circle cx="84" cy="150" r="46" fill={`url(#polka-${uid})`} />
          <circle cx="206" cy="202" r="42" fill={`url(#polka-${uid})`} />
        </>
      )}
    </svg>
  );
}

/**
 * Upper-left half-circle motif for cards (upper-right corner left clean).
 */
export function CardCornerAccents({
  leftColor,
}: {
  leftColor: string;
  rightColor?: string;
}) {
  return (
    <svg
      viewBox="0 0 64 36"
      aria-hidden="true"
      className="pointer-events-none absolute top-0 left-0 h-9 w-16 opacity-90 transition-transform duration-200 group-hover:scale-105"
    >
      <circle cx="28" cy="0" r="28" fill={leftColor} />
    </svg>
  );
}

/**
 * Clean dual-motif geometric crest emblem representing OSIS (Blue) or MPK (Red).
 */
export function OrgCrest({
  mode,
  size = 36,
}: {
  mode: OrgMode;
  size?: number;
}) {
  const primary = mode === 'osis' ? '#1d4ed8' : '#dc2626';
  const deep = mode === 'osis' ? '#172554' : '#7f1d1d';
  const contrast = '#f59e0b';

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      aria-hidden="true"
      className="shrink-0"
    >
      <circle cx="20" cy="20" r="18" fill={deep} />
      <circle cx="20" cy="20" r="14.5" stroke={contrast} strokeWidth="1.4" strokeDasharray="3 2.5" />
      <polygon
        points="20,7 31,13.5 31,26.5 20,33 9,26.5 9,13.5"
        fill={primary}
        stroke="#ffffff"
        strokeWidth="1.3"
      />
      <path
        d={
          mode === 'osis'
            ? 'M14 20.5 L18.5 25 L26.5 15.5'
            : 'M14 25 L14 15.5 L20 21.5 L26 15.5 L26 25'
        }
        stroke="#ffffff"
        strokeWidth="2.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
