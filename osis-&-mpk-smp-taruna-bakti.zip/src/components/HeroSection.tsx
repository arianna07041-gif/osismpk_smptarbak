import React from 'react';
import { OrgMode, OrgProfile } from '../data/orgData';
import { HeroBottomCurve, HexNetworkPattern } from './Motifs';

interface HeroSectionProps {
  profile: OrgProfile;
  mode: OrgMode;
  onSelectMode: (mode: OrgMode) => void;
}

export function HeroSection({
  profile,
  mode,
  onSelectMode,
}: HeroSectionProps) {
  const isOsis = mode === 'osis';

  return (
    <section
      id="sec-home"
      className={`relative flex min-h-[calc(100svh-72px)] flex-col justify-center overflow-hidden pb-28 pt-10 ${
        isOsis
          ? 'bg-gradient-to-br from-blue-100/80 via-sky-50/85 to-amber-100/70'
          : 'bg-gradient-to-br from-red-100/80 via-rose-50/85 to-amber-100/70'
      }`}
    >
      {/* Hexagonal network mesh backdrop from reference 1 */}
      <HexNetworkPattern mode={mode} />

      {/* Subtle warm contrast radial accent on the right */}
      <div
        aria-hidden="true"
        className={`pointer-events-none absolute -right-24 top-1/4 h-96 w-96 rounded-full blur-3xl ${
          isOsis ? 'bg-amber-200/45' : 'bg-amber-200/50'
        }`}
      />

      <div className="relative z-10 mx-auto w-full max-w-[1240px] px-5 sm:px-7">
        <h1
          className={`font-display text-[clamp(36px,7vw,72px)] font-extrabold uppercase leading-[1.12] ${
            isOsis ? 'text-blue-700' : 'text-red-600'
          }`}
        >
          {profile.name} SMP
          <br />
          Taruna Bakti
        </h1>

        <p className="mt-4 mb-7 max-w-[620px] text-[clamp(15px,1.6vw,18px)] leading-relaxed text-slate-600">
          {profile.fullName} · Masa jabatan 2026/2027. {profile.visi}
        </p>

        <div className="mt-2 flex flex-wrap gap-3.5">
          <button
            type="button"
            onClick={() => onSelectMode('osis')}
            aria-pressed={isOsis}
            className={`min-w-[150px] sm:min-w-[190px] rounded-xl border px-8 py-4 text-base font-extrabold tracking-[0.25em] transition-colors duration-150 ${
              isOsis
                ? 'border-blue-700 bg-blue-700 text-white hover:bg-blue-800'
                : 'border-blue-700 bg-white text-blue-700 hover:bg-blue-50'
            }`}
          >
            OSIS
          </button>

          <button
            type="button"
            onClick={() => onSelectMode('mpk')}
            aria-pressed={!isOsis}
            className={`min-w-[150px] sm:min-w-[190px] rounded-xl border px-8 py-4 text-base font-extrabold tracking-[0.25em] transition-colors duration-150 ${
              !isOsis
                ? 'border-red-600 bg-red-600 text-white hover:bg-red-700'
                : 'border-red-600 bg-white text-red-600 hover:bg-red-50'
            }`}
          >
            MPK
          </button>
        </div>
      </div>

      {/* Sweeping convex bottom curve transition into white */}
      <HeroBottomCurve />
    </section>
  );
}
