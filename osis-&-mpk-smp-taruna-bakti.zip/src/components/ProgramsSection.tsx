import React, { useRef } from 'react';
import { OrgMode, OrgProfile, UNIT_MEMBERS } from '../data/orgData';
import {
  CardCornerAccents,
  HalftoneDotMatrix,
  SectionTopArch,
  ZigzagDivider,
} from './Motifs';

interface ProgramsSectionProps {
  profile: OrgProfile;
  mode: OrgMode;
  selectedUnit: number | null;
  onSelectUnit: (index: number | null) => void;
}

export function ProgramsSection({
  profile,
  mode,
  selectedUnit,
  onSelectUnit,
}: ProgramsSectionProps) {
  const carouselRef = useRef<HTMLDivElement>(null);
  const isOsis = mode === 'osis';
  const bannerFill = isOsis ? '#172554' : '#7f1d1d';
  const unit = selectedUnit !== null ? profile.units[selectedUnit] : null;

  const slide = (dir: number) => {
    const el = carouselRef.current;
    if (el) {
      el.scrollBy({ left: dir * el.clientWidth, behavior: 'smooth' });
    }
  };

  return (
    <section id="sec-prog" className="relative bg-white">
      {/* Deep Curved Arch extending all the way down to the line before Kegiatan (OSIS) / Aspirasi (MPK) */}
      <SectionTopArch fill={bannerFill} />

      <div
        className={`relative overflow-hidden pb-16 pt-6 sm:pb-20 sm:pt-10 ${
          isOsis ? 'bg-[#172554]' : 'bg-[#7f1d1d]'
        }`}
      >
        <HalftoneDotMatrix mode={mode} />

        <div className="relative z-10 mx-auto max-w-[1240px] px-5 text-center sm:px-7">
          <h2 className="font-display text-[clamp(26px,3.4vw,38px)] font-extrabold text-white">
            {profile.unitLabel} {profile.name}
          </h2>
          <ZigzagDivider
            color={isOsis ? '#93c5fd' : '#fde68a'}
            className="mt-3"
          />

          {selectedUnit === null && (
            <div className="mt-5 mb-8 flex justify-center gap-2.5">
              <button
                type="button"
                onClick={() => slide(-1)}
                aria-label="Geser ke kiri"
                className={`grid h-[52px] w-[52px] place-items-center rounded-full text-[22px] font-bold text-white transition-colors ${
                  isOsis
                    ? 'bg-blue-600 hover:bg-blue-500'
                    : 'bg-red-600 hover:bg-red-500'
                }`}
              >
                ‹
              </button>
              <button
                type="button"
                onClick={() => slide(1)}
                aria-label="Geser ke kanan"
                className={`grid h-[52px] w-[52px] place-items-center rounded-full text-[22px] font-bold text-white transition-colors ${
                  isOsis
                    ? 'bg-blue-600 hover:bg-blue-500'
                    : 'bg-red-600 hover:bg-red-500'
                }`}
              >
                ›
              </button>
            </div>
          )}
        </div>

        {/* Carousel or Detail View fully inside the extended arch background */}
        <div className="relative z-10 mx-auto max-w-[1240px] px-5 sm:px-7">
          {unit && selectedUnit !== null ? (
            <div
              id="sec-detail"
              className="mx-auto mt-6 max-w-[880px] rounded-[18px] border border-slate-200 bg-white p-6 shadow-xl sm:p-8"
            >
              <div className="mb-6 text-center">
                <h2
                  className={`font-display text-[clamp(22px,3vw,30px)] font-extrabold ${
                    isOsis ? 'text-blue-700' : 'text-red-600'
                  }`}
                >
                  {profile.unitLabel.toUpperCase()} {unit.code} - {unit.shortTitle}
                </h2>
                <button
                  type="button"
                  onClick={() => onSelectUnit(null)}
                  className={`mt-3.5 rounded-[10px] border bg-white px-6 py-2.5 text-sm font-semibold transition-colors ${
                    isOsis
                      ? 'border-blue-700 text-blue-700 hover:bg-blue-50'
                      : 'border-red-600 text-red-600 hover:bg-red-50'
                  }`}
                >
                  ← Semua {profile.unitLabel}
                </button>
              </div>

              <div className="grid gap-4 md:grid-cols-[1fr_1.7fr]">
                {/* Left Proker Card */}
                <div
                  className={`relative overflow-hidden rounded-[14px] border bg-white p-[18px] ${
                    isOsis ? 'border-blue-600' : 'border-red-600'
                  }`}
                >
                  <CardCornerAccents leftColor={unit.accentLeft} />
                  <div
                    className={`relative z-10 mx-auto mb-3 grid h-[116px] w-[116px] place-items-center rounded-full border-[6px] font-display text-[32px] font-extrabold ${
                      isOsis
                        ? 'border-blue-50 text-blue-700 outline-2 outline-blue-700 -outline-offset-8'
                        : 'border-red-50 text-red-600 outline-2 outline-red-600 -outline-offset-8'
                    }`}
                  >
                    {unit.code}
                  </div>
                  <div className="relative z-10 font-display text-lg font-extrabold text-slate-700">
                    Proker:
                  </div>
                  <ul className="relative z-10 my-2 list-disc space-y-2 pl-5 text-[15px]">
                    {unit.proker.map((p) => (
                      <li key={p.title}>
                        <b>{p.title}</b> -{' '}
                        <span className="text-slate-500">{p.description}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Right 2-col Members Grid */}
                <div className="grid grid-cols-2 gap-3">
                  {UNIT_MEMBERS.map((member, mIdx) => {
                    const roleText =
                      member.rolePrefix === 'Anggota'
                        ? 'Anggota'
                        : `${member.rolePrefix} ${profile.unitLabel} ${unit.code}`;

                    return (
                      <div
                        key={`${member.rolePrefix}-${mIdx}`}
                        className="rounded-[14px] border border-slate-200 bg-white p-[18px] shadow-[0_8px_24px_rgba(31,41,55,0.03)]"
                      >
                        <div
                          className={`mb-2.5 aspect-4/3 rounded-xl ${
                            isOsis ? 'bg-blue-50' : 'bg-red-50'
                          }`}
                        />
                        <span
                          className={`mb-1.5 inline-block rounded-[7px] px-2.5 py-0.5 text-[13px] font-bold text-white ${
                            isOsis ? 'bg-blue-700' : 'bg-red-600'
                          }`}
                        >
                          {roleText}
                        </span>
                        <div className="font-display text-base font-extrabold text-slate-900">
                          {member.name}
                        </div>
                        <div className="text-sm text-slate-500">{member.kelas}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div
              ref={carouselRef}
              className="flex snap-x snap-mandatory gap-5 overflow-x-auto px-1 pb-2 pt-1.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
            >
              {profile.units.map((u, idx) => (
                <div
                  key={u.code}
                  className="group relative flex shrink-0 basis-[78%] snap-start flex-col overflow-hidden rounded-[18px] border border-white/15 bg-white p-[22px] shadow-xl sm:basis-[calc((100%-20px)/2)] lg:basis-[calc((100%-60px)/4)]"
                >
                  <CardCornerAccents leftColor={u.accentLeft} />

                  <div
                    className={`relative z-10 mx-auto mb-3.5 grid h-[128px] w-[128px] place-items-center rounded-full border-[6px] font-display text-[38px] font-extrabold ${
                      isOsis
                        ? 'border-blue-50 text-blue-700 outline-2 outline-blue-700 -outline-offset-10'
                        : 'border-red-50 text-red-600 outline-2 outline-red-600 -outline-offset-10'
                    }`}
                  >
                    {u.code}
                  </div>

                  <span
                    className={`relative z-10 mb-2.5 self-start rounded-[7px] px-3 py-1 text-[13px] font-bold text-white ${
                      isOsis ? 'bg-blue-700' : 'bg-red-600'
                    }`}
                  >
                    {profile.unitLabel.toUpperCase()} {u.code}
                  </span>

                  <h3 className="relative z-10 mb-3.5 flex-1 font-display text-[15px] font-extrabold leading-[1.45] text-slate-700">
                    {u.fullTitle}
                  </h3>

                  <button
                    type="button"
                    onClick={() => onSelectUnit(idx)}
                    className={`relative z-10 self-start rounded-[10px] px-3.5 py-2.5 text-sm font-semibold text-white transition-colors ${
                      isOsis
                        ? 'bg-blue-700 hover:bg-blue-800'
                        : 'bg-red-600 hover:bg-red-700'
                    }`}
                  >
                    Lihat Selengkapnya →
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
