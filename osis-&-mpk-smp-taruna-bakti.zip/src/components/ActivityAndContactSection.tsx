import React, { useState } from 'react';
import { AGENDA_ITEMS, FAQ_ITEMS, OrgMode, OrgProfile } from '../data/orgData';
import { CardCornerAccents, ZigzagDivider } from './Motifs';

interface ActivityAndContactSectionProps {
  profile: OrgProfile;
  mode: OrgMode;
  onScrollHome: () => void;
}

export function ActivityAndContactSection({
  profile,
  mode,
  onScrollHome,
}: ActivityAndContactSectionProps) {
  const isOsis = mode === 'osis';

  const [formOpen, setFormOpen] = useState(false);
  const [nama, setNama] = useState('');
  const [kelas, setKelas] = useState('');
  const [aspirasi, setAspirasi] = useState('');
  const [errors, setErrors] = useState<{ nama?: string; kelas?: string; aspirasi?: string }>({});
  const [submitted, setSubmitted] = useState(false);
  const [faqQuery, setFaqQuery] = useState('');

  const filteredAgenda = AGENDA_ITEMS.filter(
    (item) => item.scope === 'both' || item.scope === mode
  );

  const filteredFaq = FAQ_ITEMS.filter((item) =>
    `${item.question} ${item.answer}`.toLowerCase().includes(faqQuery.toLowerCase())
  );

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: { nama?: string; kelas?: string; aspirasi?: string } = {};
    if (!nama.trim()) nextErrors.nama = 'Nama wajib diisi.';
    if (!kelas.trim()) nextErrors.kelas = 'Kelas wajib diisi.';
    if (aspirasi.trim().length < 10) nextErrors.aspirasi = 'Tulis minimal 10 karakter.';

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    setErrors({});
    setSubmitted(true);
  };

  const resetAspirasi = () => {
    setNama('');
    setKelas('');
    setAspirasi('');
    setErrors({});
    setSubmitted(false);
    setFormOpen(false);
    onScrollHome();
  };

  const headingColor = isOsis ? 'text-blue-700' : 'text-red-600';
  const accentBtn = isOsis
    ? 'border border-blue-700 bg-blue-700 text-white hover:bg-blue-800'
    : 'border border-red-600 bg-red-600 text-white hover:bg-red-700';
  const outlineBtn = isOsis
    ? 'border border-blue-700 bg-white text-blue-700 hover:bg-blue-50'
    : 'border border-red-600 bg-white text-red-600 hover:bg-red-50';

  return (
    <>
      {/* Kegiatan Section (OSIS mode, matching original) */}
      {isOsis && (
        <section id="sec-act" className="border-t border-slate-200 bg-white py-16 sm:py-20">
          <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
            <h2 className="font-display text-[clamp(26px,3.4vw,38px)] font-extrabold text-blue-700">
              Kegiatan
            </h2>
            <ZigzagDivider color="#14b8a6" className="mx-0! mt-3 mb-6" />

            <div id="sec-agenda">
              {filteredAgenda.map((item, idx) => (
                <div
                  key={item.title}
                  className={`flex items-center gap-[18px] py-5 ${
                    idx < filteredAgenda.length - 1 ? 'border-b border-slate-200' : ''
                  }`}
                >
                  <div className="min-w-[68px] text-center font-display text-[26px] font-extrabold leading-none text-blue-700 tabular-nums">
                    {item.day}
                    <small className="mt-1 block text-[13px] font-bold text-amber-600">
                      {item.month}
                    </small>
                  </div>
                  <div>
                    <h3 className="m-0 text-[19px] font-bold text-slate-900">
                      {item.title}
                    </h3>
                    <div className="text-[15px] text-slate-500">{item.location}</div>
                  </div>
                </div>
              ))}
            </div>

            <h3 id="sec-doc" className="mt-10 mb-3.5 text-[19px] font-bold text-slate-900">
              Dokumentasi
            </h3>
            <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
              {[
                { left: '#bae6fd', right: '#fde68a' },
                { left: '#a7f3d0', right: '#bfdbfe' },
                { left: '#fbcfe8', right: '#fed7aa' },
              ].map((accent, idx) => (
                <div
                  key={idx}
                  className="relative grid aspect-16/10 place-items-center overflow-hidden rounded-xl border border-slate-200 bg-blue-50/70 text-[13px] text-slate-500"
                >
                  <CardCornerAccents leftColor={accent.left} rightColor={accent.right} />
                  <span className="relative z-10">Segera hadir</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Original Vertical Flow: Aspirasi -> FAQ -> Kontak */}
      <section id="sec-contact" className="border-t border-slate-200 bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
          {/* Aspirasi */}
          <h2 className={`font-display text-[clamp(26px,3.4vw,38px)] font-extrabold ${headingColor}`}>
            Aspirasi
          </h2>
          <ZigzagDivider
            color={isOsis ? '#2563eb' : '#dc2626'}
            className="mx-0! mt-3 mb-6"
          />

          <div id="sec-form">
            {submitted ? (
              <div className="py-8 text-center">
                <div
                  className={`mx-auto mb-3 grid h-[68px] w-[68px] place-items-center rounded-full text-[30px] ${
                    isOsis ? 'bg-blue-50 text-blue-700' : 'bg-red-50 text-red-600'
                  }`}
                >
                  ✓
                </div>
                <h3 className="text-[19px] font-bold text-slate-900">Aspirasi terkirim</h3>
                <p className="mt-2 text-slate-600">
                  Terima kasih, {nama}. Aspirasimu akan ditanggapi maksimal 7 hari kerja.
                </p>
                <button
                  type="button"
                  onClick={resetAspirasi}
                  className={`mt-4 rounded-[10px] px-7 py-3.5 text-base font-semibold transition-colors ${accentBtn}`}
                >
                  Kembali ke Beranda
                </button>
              </div>
            ) : !formOpen ? (
              <div>
                <p className="mb-4 text-slate-600">
                  Punya saran atau masukan untuk sekolah? Sampaikan di sini.
                </p>
                <button
                  type="button"
                  onClick={() => setFormOpen(true)}
                  className={`rounded-[10px] px-7 py-3.5 text-base font-semibold transition-colors ${accentBtn}`}
                >
                  Tulis aspirasi
                </button>
              </div>
            ) : (
              <form onSubmit={handleFormSubmit} noValidate className="max-w-[560px]">
                {Object.keys(errors).length > 0 && (
                  <div className="mb-3 rounded-[10px] border border-red-600 px-3.5 py-2.5 text-[13px] text-red-700">
                    Formulir belum lengkap. Periksa kolom yang ditandai lalu coba kirim lagi.
                  </div>
                )}

                <div>
                  <label htmlFor="asp-nama" className="mt-3.5 mb-1.5 block text-[15px] font-semibold">
                    Nama (boleh inisial)
                  </label>
                  <input
                    id="asp-nama"
                    type="text"
                    value={nama}
                    onChange={(e) => setNama(e.target.value)}
                    className={`w-full rounded-[10px] border bg-white p-3.5 text-base text-slate-900 ${
                      errors.nama ? 'border-red-600' : 'border-slate-200'
                    }`}
                  />
                  {errors.nama && <div className="mt-1 text-xs text-red-600">{errors.nama}</div>}
                </div>

                <div>
                  <label htmlFor="asp-kelas" className="mt-3.5 mb-1.5 block text-[15px] font-semibold">
                    Kelas
                  </label>
                  <input
                    id="asp-kelas"
                    type="text"
                    placeholder="Contoh: 8A"
                    value={kelas}
                    onChange={(e) => setKelas(e.target.value)}
                    className={`w-full rounded-[10px] border bg-white p-3.5 text-base text-slate-900 ${
                      errors.kelas ? 'border-red-600' : 'border-slate-200'
                    }`}
                  />
                  {errors.kelas && <div className="mt-1 text-xs text-red-600">{errors.kelas}</div>}
                </div>

                <div>
                  <label htmlFor="asp-isi" className="mt-3.5 mb-1.5 block text-[15px] font-semibold">
                    Aspirasi
                  </label>
                  <textarea
                    id="asp-isi"
                    rows={5}
                    value={aspirasi}
                    onChange={(e) => setAspirasi(e.target.value)}
                    className={`w-full rounded-[10px] border bg-white p-3.5 text-base text-slate-900 ${
                      errors.aspirasi ? 'border-red-600' : 'border-slate-200'
                    }`}
                  />
                  {errors.aspirasi && (
                    <div className="mt-1 text-xs text-red-600">{errors.aspirasi}</div>
                  )}
                </div>

                <div className="mt-4 flex flex-wrap gap-2.5">
                  <button
                    type="submit"
                    className={`rounded-[10px] px-7 py-3.5 text-base font-semibold transition-colors ${accentBtn}`}
                  >
                    Kirim aspirasi
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setFormOpen(false);
                      setErrors({});
                    }}
                    className={`rounded-[10px] px-7 py-3.5 text-base font-semibold transition-colors ${outlineBtn}`}
                  >
                    Batal
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* FAQ */}
          <h2
            id="sec-faq"
            className={`mt-16 mb-6 font-display text-[clamp(26px,3.4vw,38px)] font-extrabold ${headingColor}`}
          >
            FAQ
          </h2>
          <input
            type="search"
            placeholder="Cari pertanyaan…"
            value={faqQuery}
            onChange={(e) => setFaqQuery(e.target.value)}
            aria-label="Cari pertanyaan FAQ"
            className="w-full rounded-[10px] border border-slate-200 bg-white p-3.5 text-base text-slate-900"
          />

          <div className="mt-2">
            {filteredFaq.length > 0 ? (
              filteredFaq.map((item) => (
                <details key={item.question} className="border-b border-slate-200 py-3.5">
                  <summary className="cursor-pointer text-[17px] font-semibold text-slate-900">
                    {item.question}
                  </summary>
                  <p className="mt-2 text-slate-600">{item.answer}</p>
                </details>
              ))
            ) : (
              <div className="py-8 text-center">
                <div
                  className={`mx-auto mb-3 grid h-[68px] w-[68px] place-items-center rounded-full text-[30px] ${
                    isOsis ? 'bg-blue-50 text-blue-700' : 'bg-red-50 text-red-600'
                  }`}
                >
                  –
                </div>
                <h3 className="text-[19px] font-bold text-slate-900">Hasil pencarian kosong</h3>
                <p className="mt-2 text-slate-600">
                  Tidak ada pertanyaan untuk “{faqQuery}”.
                </p>
                <button
                  type="button"
                  onClick={() => setFaqQuery('')}
                  className={`mt-4 rounded-[10px] px-6 py-3 text-base font-semibold transition-colors ${outlineBtn}`}
                >
                  Lihat semua FAQ
                </button>
              </div>
            )}
          </div>

          {/* Kontak & Media Sosial */}
          <h2
            id="sec-kontak"
            className={`mt-16 mb-6 font-display text-[clamp(26px,3.4vw,38px)] font-extrabold ${headingColor}`}
          >
            Kontak & Media Sosial
          </h2>
          <p className="m-0 text-slate-600">
            Instagram: {profile.instagram}
            <br />
            Email: {profile.email}
          </p>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-white py-5 text-sm text-slate-500">
        <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
          © 2026 {profile.name} SMP Taruna Bakti · Data contoh.
        </div>
      </footer>
    </>
  );
}
