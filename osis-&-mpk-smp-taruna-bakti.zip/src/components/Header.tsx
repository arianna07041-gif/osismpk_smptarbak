import React, { useState } from 'react';
import { ChevronDown, Menu, X } from 'lucide-react';
import { AGENDA_ITEMS, ORG_DATA, OrgMode } from '../data/orgData';

interface HeaderProps {
  mode: OrgMode;
  activeSection: string;
  onNavigateSection: (sectionId: string) => void;
  onOpenUnit: (targetMode: OrgMode, unitIndex: number) => void;
  onGoActivity: () => void;
}

export function Header({
  mode,
  activeSection,
  onNavigateSection,
  onOpenUnit,
  onGoActivity,
}: HeaderProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    main: true,
    osis: true,
    mpk: true,
    agenda: false,
  });

  const isOsis = mode === 'osis';
  const accentText = isOsis ? 'text-blue-700' : 'text-red-700';
  const accentBg = isOsis ? 'bg-blue-700 hover:bg-blue-800' : 'bg-red-600 hover:bg-red-700';
  const activeBar = isOsis ? 'bg-blue-700' : 'bg-red-600';
  const hoverText = isOsis ? 'hover:text-blue-700' : 'hover:text-red-700';

  const navLinks = [
    { id: 'sec-home', label: 'Beranda' },
    { id: 'sec-visi', label: 'Visi' },
    { id: 'sec-misi', label: 'Misi' },
    { id: 'sec-prog', label: 'Program Kerja' },
    { id: 'sec-org', label: 'Struktur Organisasi' },
  ];

  const toggleGroup = (key: string) => {
    setOpenGroups((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleNav = (id: string) => {
    setDrawerOpen(false);
    onNavigateSection(id);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/94 backdrop-blur-md">
      <div className="mx-auto flex h-18 max-w-[1240px] items-center gap-7 px-5 sm:px-7">
        {/* Brand */}
        <button
          type="button"
          onClick={() => handleNav('sec-home')}
          className={`shrink-0 text-left font-bold whitespace-nowrap text-base sm:text-lg ${accentText}`}
        >
          OSIS/MPK SMP Taruna Bakti
        </button>

        {/* Nav Links (matching original 5 links) */}
        <nav className="ml-auto hidden items-center gap-7 lg:flex" aria-label="Navigasi utama">
          {navLinks.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => handleNav(link.id)}
                className={`relative flex h-18 items-center text-[15px] font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                  isActive ? `${accentText} font-semibold` : `text-slate-700 ${hoverText}`
                }`}
              >
                {link.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className={`absolute inset-x-0 bottom-0 h-0.5 ${activeBar}`}
                  />
                )}
              </button>
            );
          })}
        </nav>

        <span className="hidden h-7 w-px bg-slate-200 lg:block" aria-hidden="true" />

        {/* Hamburger Menu Button */}
        <button
          type="button"
          onClick={() => setDrawerOpen((prev) => !prev)}
          aria-expanded={drawerOpen}
          aria-controls="site-nav-drawer"
          aria-label={drawerOpen ? 'Tutup menu' : 'Buka menu'}
          className={`ml-auto inline-flex h-10 w-13 shrink-0 items-center justify-center rounded-lg text-white transition-colors duration-150 lg:ml-0 ${accentBg}`}
        >
          {drawerOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Dropdown Accordion Drawer (matching original .dd) */}
      {drawerOpen && (
        <>
          <div
            className="fixed inset-0 top-18 z-30 bg-slate-950/20"
            onClick={() => setDrawerOpen(false)}
            aria-hidden="true"
          />
          <div
            id="site-nav-drawer"
            className="absolute right-5 top-18 z-40 max-h-[80vh] w-[min(340px,92vw)] overflow-y-auto rounded-xl border border-slate-200 bg-white px-4 py-2.5 shadow-xl sm:right-7"
          >
            <div className="mb-2 border-b border-slate-100 pb-2">
              <button
                type="button"
                onClick={() => toggleGroup('main')}
                className="flex w-full items-center justify-between border-b border-slate-100 py-2.5 text-left text-[15px] font-semibold text-slate-900"
              >
                <span>Halaman Utama</span>
                <ChevronDown
                  className={`h-4 w-4 text-slate-600 transition-transform ${
                    openGroups.main ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openGroups.main && (
                <div className="pt-1">
                  {[
                    ['sec-visi', 'Visi'],
                    ['sec-misi', 'Misi'],
                    ['sec-prog', 'Program Kerja'],
                    ['sec-org', 'Struktur Organisasi'],
                    ['sec-contact', 'Kontak & Aspirasi'],
                    ['sec-faq', 'FAQ'],
                  ].map(([id, label]) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => handleNav(id)}
                      className={`block w-full py-2 text-left text-sm text-slate-700 ${hoverText}`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="mb-2 border-b border-slate-100 pb-2">
              <button
                type="button"
                onClick={() => toggleGroup('osis')}
                className="flex w-full items-center justify-between border-b border-slate-100 py-2.5 text-left text-[15px] font-semibold text-blue-700"
              >
                <span>OSIS</span>
                <ChevronDown
                  className={`h-4 w-4 text-blue-600 transition-transform ${
                    openGroups.osis ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openGroups.osis && (
                <div className="pt-1">
                  {ORG_DATA.osis.units.map((u, idx) => (
                    <button
                      key={u.code}
                      type="button"
                      onClick={() => {
                        setDrawerOpen(false);
                        onOpenUnit('osis', idx);
                      }}
                      className="block w-full py-2 text-left text-sm text-slate-700 hover:text-blue-700"
                    >
                      Sekbid {u.code} - {u.shortTitle}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="mb-2 border-b border-slate-100 pb-2">
              <button
                type="button"
                onClick={() => toggleGroup('mpk')}
                className="flex w-full items-center justify-between border-b border-slate-100 py-2.5 text-left text-[15px] font-semibold text-red-700"
              >
                <span>MPK</span>
                <ChevronDown
                  className={`h-4 w-4 text-red-600 transition-transform ${
                    openGroups.mpk ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openGroups.mpk && (
                <div className="pt-1">
                  {ORG_DATA.mpk.units.map((u, idx) => (
                    <button
                      key={u.code}
                      type="button"
                      onClick={() => {
                        setDrawerOpen(false);
                        onOpenUnit('mpk', idx);
                      }}
                      className="block w-full py-2 text-left text-sm text-slate-700 hover:text-red-700"
                    >
                      Komisi {u.code} - {u.shortTitle}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div>
              <button
                type="button"
                onClick={() => toggleGroup('agenda')}
                className="flex w-full items-center justify-between border-b border-slate-100 py-2.5 text-left text-[15px] font-semibold text-slate-900"
              >
                <span>Kegiatan OSIS 2026/2027</span>
                <ChevronDown
                  className={`h-4 w-4 text-slate-600 transition-transform ${
                    openGroups.agenda ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openGroups.agenda && (
                <div className="pt-1">
                  {AGENDA_ITEMS.filter((item) => item.scope !== 'mpk').map((item) => (
                    <button
                      key={item.title}
                      type="button"
                      onClick={() => {
                        setDrawerOpen(false);
                        onGoActivity();
                      }}
                      className="block w-full py-2 text-left text-sm text-slate-700 hover:text-blue-700"
                    >
                      {item.day} {item.month} - {item.title}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </header>
  );
}
