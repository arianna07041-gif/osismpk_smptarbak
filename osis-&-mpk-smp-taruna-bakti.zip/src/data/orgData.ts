export type OrgMode = 'osis' | 'mpk';

export interface ProkerItem {
  title: string;
  description: string;
}

export interface UnitItem {
  code: string;
  shortTitle: string;
  fullTitle: string;
  accentLeft: string;
  accentRight: string;
  proker: ProkerItem[];
}

export interface CoreMember {
  role: string;
  name: string;
}

export interface PillarItem {
  title: string;
  description: string;
}

export interface OrgProfile {
  mode: OrgMode;
  name: string;
  fullName: string;
  unitLabel: string;
  tagline: string;
  visi: string;
  misi: string[];
  pillars: PillarItem[];
  core: CoreMember[];
  units: UnitItem[];
  instagram: string;
  email: string;
}

export interface AgendaItem {
  day: string;
  month: string;
  title: string;
  scope: 'both' | 'osis' | 'mpk';
  location: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export const ORG_DATA: Record<OrgMode, OrgProfile> = {
  osis: {
    mode: 'osis',
    name: 'OSIS',
    fullName: 'Organisasi Siswa Intra Sekolah',
    unitLabel: 'Sekbid',
    tagline: 'Berkarakter, Kreatif, dan Berprestasi dalam Bingkai Persatuan',
    visi: 'Mewujudkan OSIS SMP Taruna Bakti yang berkarakter, kreatif, dan berprestasi dalam bingkai persatuan.',
    misi: [
      'Menumbuhkan ketakwaan dan budi pekerti luhur',
      'Mengembangkan kepemimpinan dan kemampuan berorganisasi',
      'Mewadahi minat, bakat, dan kreativitas siswa',
      'Menjalin kerja sama dengan seluruh warga sekolah',
    ],
    pillars: [
      {
        title: 'Ketakwaan & Akhlak Mulia',
        description: 'Membangun karakter siswa yang religius, santun, dan peduli terhadap sesama melalui pembiasaan harian.',
      },
      {
        title: 'Prestasi & Kreativitas',
        description: 'Menghadirkan ruang kompetisi akademik, olahraga, seni, dan kewirausahaan bagi seluruh siswa.',
      },
      {
        title: 'Kebangsaan & Persatuan',
        description: 'Menumbuhkan semangat cinta tanah air, toleransi sosial, serta kedisiplinan dalam berorganisasi.',
      },
    ],
    core: [
      { role: 'Ketua Umum', name: 'Nama Ketua Umum' },
      { role: 'Ketua 1', name: 'Nama Ketua 1' },
      { role: 'Ketua 2', name: 'Nama Ketua 2' },
      { role: 'Bendahara 1', name: 'Nama Bendahara' },
      { role: 'Bendahara 2', name: 'Nama Bendahara' },
      { role: 'Sekretaris 1', name: 'Nama Sekretaris' },
      { role: 'Sekretaris 2', name: 'Nama Sekretaris' },
    ],
    units: [
      {
        code: '1',
        shortTitle: 'Keimanan & Ketaqwaan',
        fullTitle: 'Keimanan dan Ketaqwaan kepada Tuhan yang Maha Esa',
        accentLeft: '#bae6fd',
        accentRight: '#fde68a',
        proker: [
          { title: 'Retret Keagamaan', description: 'Kegiatan ibadah di luar sekolah untuk memperdalam keimanan.' },
          { title: 'Satgas Ibadah Siang', description: 'Menertibkan dan melancarkan ibadah siang.' },
        ],
      },
      {
        code: '2',
        shortTitle: 'Budi Pekerti',
        fullTitle: 'Budi Pekerti dan Akhlak Mulia',
        accentLeft: '#fbcfe8',
        accentRight: '#bfdbfe',
        proker: [
          { title: 'Kampanye 5S', description: 'Membiasakan senyum, salam, sapa, sopan, santun.' },
          { title: 'Jumat Berkah', description: 'Berbagi kepada sesama setiap Jumat.' },
        ],
      },
      {
        code: '3',
        shortTitle: 'Bela Negara',
        fullTitle: 'Kepribadian Unggul, Wawasan Kebangsaan, dan Bela Negara',
        accentLeft: '#a7f3d0',
        accentRight: '#fde68a',
        proker: [
          { title: 'Upacara Bergilir', description: 'Petugas upacara dari seluruh kelas.' },
          { title: 'Hari Pahlawan', description: 'Lomba dan upacara bertema kepahlawanan.' },
        ],
      },
      {
        code: '4',
        shortTitle: 'Prestasi & Olahraga',
        fullTitle: 'Prestasi Akademik, Olahraga, dan Jasmani',
        accentLeft: '#fed7aa',
        accentRight: '#bae6fd',
        proker: [
          { title: 'Class Meeting', description: 'Lomba olahraga antarkelas.' },
          { title: 'Klinik Belajar', description: 'Belajar bersama untuk persiapan ujian.' },
        ],
      },
      {
        code: '5',
        shortTitle: 'Demokrasi & HAM',
        fullTitle: 'Demokrasi, HAM, dan Toleransi Sosial',
        accentLeft: '#c7d2fe',
        accentRight: '#fbcfe8',
        proker: [
          { title: 'Pemilihan Ketua OSIS', description: 'Pemilihan langsung oleh siswa.' },
          { title: 'Hari Toleransi', description: 'Diskusi dan kampanye toleransi.' },
        ],
      },
      {
        code: '6',
        shortTitle: 'Kreativitas & Wirausaha',
        fullTitle: 'Kreativitas dan Kewirausahaan',
        accentLeft: '#fde68a',
        accentRight: '#a7f3d0',
        proker: [
          { title: 'Bazar Kelas', description: 'Latihan berwirausaha.' },
          { title: 'Pameran Karya', description: 'Menampilkan karya siswa.' },
        ],
      },
      {
        code: '7',
        shortTitle: 'Sastra & Budaya',
        fullTitle: 'Sastra dan Budaya',
        accentLeft: '#ddd6fe',
        accentRight: '#fed7aa',
        proker: [
          { title: 'Pentas Seni', description: 'Pertunjukan seni dan budaya.' },
          { title: 'Lomba Cipta Puisi', description: 'Menumbuhkan minat sastra.' },
        ],
      },
      {
        code: '8',
        shortTitle: 'Teknologi & Informasi',
        fullTitle: 'Teknologi Informasi dan Komunikasi',
        accentLeft: '#99f6e4',
        accentRight: '#bfdbfe',
        proker: [
          { title: 'Publikasi Media Sosial', description: 'Pengelolaan akun resmi OSIS.' },
          { title: 'Pelatihan Desain', description: 'Belajar desain poster dan video.' },
        ],
      },
    ],
    instagram: '@osis.tarunabakti',
    email: 'osis@smptarunabakti.sch.id',
  },
  mpk: {
    mode: 'mpk',
    name: 'MPK',
    fullName: 'Majelis Perwakilan Kelas',
    unitLabel: 'Komisi',
    tagline: 'Aspiratif, Amanah, dan Transparan bagi Seluruh Siswa',
    visi: 'Menjadi wadah aspirasi siswa SMP Taruna Bakti yang aspiratif, amanah, dan transparan.',
    misi: [
      'Menampung dan menyalurkan aspirasi siswa',
      'Mengawasi pelaksanaan program kerja OSIS',
      'Menjaga kerja sama antarlembaga kesiswaan',
      'Mendorong budaya musyawarah di sekolah',
    ],
    pillars: [
      {
        title: 'Suara & Aspirasi Siswa',
        description: 'Menjembatani masukan, kritik, dan gagasan siswa secara terbuka kepada pihak sekolah dan OSIS.',
      },
      {
        title: 'Pengawasan Transparan',
        description: 'Mengawal anggaran, kinerja bidang, dan pelaksanaan setiap program kerja secara objektif.',
      },
      {
        title: 'Budaya Musyawarah',
        description: 'Menegakkan dialog yang demokratis, adil, dan akuntabel antarperwakilan kelas.',
      },
    ],
    core: [
      { role: 'Ketua Umum', name: 'Nama Ketua Umum' },
      { role: 'Ketua 1', name: 'Nama Ketua 1' },
      { role: 'Ketua 2', name: 'Nama Ketua 2' },
      { role: 'Bendahara 1', name: 'Nama Bendahara' },
      { role: 'Bendahara 2', name: 'Nama Bendahara' },
      { role: 'Sekretaris 1', name: 'Nama Sekretaris' },
      { role: 'Sekretaris 2', name: 'Nama Sekretaris' },
    ],
    units: [
      {
        code: 'A',
        shortTitle: 'Pengawasan Anggaran',
        fullTitle: 'Mengawasi Anggaran Kegiatan OSIS',
        accentLeft: '#fecaca',
        accentRight: '#fde68a',
        proker: [
          { title: 'Audit Anggaran', description: 'Memeriksa penggunaan dana kegiatan OSIS.' },
          { title: 'Laporan Keuangan', description: 'Meninjau laporan keuangan tiap semester.' },
        ],
      },
      {
        code: 'B',
        shortTitle: 'Pengawasan Akademik',
        fullTitle: 'Mengawasi Akademik Anggota OSIS',
        accentLeft: '#fed7aa',
        accentRight: '#bfdbfe',
        proker: [
          { title: 'Pemantauan Nilai', description: 'Memantau capaian akademik pengurus.' },
          { title: 'Pendampingan Belajar', description: 'Membantu anggota yang tertinggal.' },
        ],
      },
      {
        code: 'C',
        shortTitle: 'Pengawasan Sekbid',
        fullTitle: 'Mengawasi Sekbid OSIS',
        accentLeft: '#fde68a',
        accentRight: '#fecdd3',
        proker: [
          { title: 'Monitoring Proker Sekbid', description: 'Memantau pelaksanaan program sekbid.' },
          { title: 'Rapat Evaluasi', description: 'Evaluasi tiap semester.' },
        ],
      },
      {
        code: 'D',
        shortTitle: 'Hubungan Masyarakat',
        fullTitle: 'Hubungan Masyarakat',
        accentLeft: '#fbcfe8',
        accentRight: '#a7f3d0',
        proker: [
          { title: 'Publikasi', description: 'Informasi kegiatan MPK.' },
          { title: 'Kotak Aspirasi', description: 'Menampung aspirasi siswa.' },
        ],
      },
      {
        code: 'E',
        shortTitle: 'Evaluasi Kegiatan',
        fullTitle: 'Mengevaluasi Kegiatan OSIS',
        accentLeft: '#fecdd3',
        accentRight: '#ddd6fe',
        proker: [
          { title: 'Evaluasi Kegiatan', description: 'Menilai pelaksanaan kegiatan OSIS.' },
          { title: 'Arsip Kegiatan', description: 'Dokumentasi seluruh kegiatan.' },
        ],
      },
    ],
    instagram: '@mpk.tarunabakti',
    email: 'mpk@smptarunabakti.sch.id',
  },
};

export const UNIT_MEMBERS = [
  { rolePrefix: 'Ketua', name: 'Nama Ketua', kelas: 'VIII-A' },
  { rolePrefix: 'Wakil Ketua', name: 'Nama Wakil Ketua', kelas: 'VIII-A' },
  { rolePrefix: 'Anggota', name: 'Nama Anggota', kelas: 'VII-B' },
  { rolePrefix: 'Anggota', name: 'Nama Anggota', kelas: 'VII-C' },
  { rolePrefix: 'Anggota', name: 'Nama Anggota', kelas: 'VII-A' },
  { rolePrefix: 'Anggota', name: 'Nama Anggota', kelas: 'VIII-C' },
];

export const AGENDA_ITEMS: AgendaItem[] = [
  { day: '18', month: 'OKT', title: 'Serah Terima Jabatan', scope: 'both', location: 'Aula sekolah · 08.00' },
  { day: '24', month: 'OKT', title: 'Jumat Bersih & Bank Sampah', scope: 'osis', location: 'Halaman sekolah · 07.00' },
  { day: '02', month: 'NOV', title: 'Forum Dengar Aspirasi', scope: 'mpk', location: 'Ruang multimedia · 10.00' },
  { day: '10', month: 'NOV', title: 'Peringatan Hari Pahlawan', scope: 'both', location: 'Lapangan · 07.00' },
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    question: 'Siapa yang boleh mengirim aspirasi?',
    answer: 'Semua siswa SMP Taruna Bakti, dengan nama atau inisial.',
  },
  {
    question: 'Berapa lama aspirasi ditanggapi?',
    answer: 'Maksimal 7 hari kerja.',
  },
  {
    question: 'Bagaimana cara menjadi pengurus?',
    answer: 'Pendaftaran dibuka setiap awal tahun ajaran melalui pembina.',
  },
  {
    question: 'Apa beda OSIS dan MPK?',
    answer: 'OSIS menjalankan program kerja, MPK menampung aspirasi dan mengawasi.',
  },
];
