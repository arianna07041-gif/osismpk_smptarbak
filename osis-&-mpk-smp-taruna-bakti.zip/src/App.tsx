import React, { useEffect, useState } from 'react';
import { ORG_DATA, OrgMode } from './data/orgData';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { StructureSection } from './components/StructureSection';
import { ProgramsSection } from './components/ProgramsSection';
import { ActivityAndContactSection } from './components/ActivityAndContactSection';

export default function App() {
  const [mode, setMode] = useState<OrgMode>('osis');
  const [selectedUnit, setSelectedUnit] = useState<number | null>(null);
  const [activeSection, setActiveSection] = useState<string>('sec-home');

  const profile = ORG_DATA[mode];

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleSelectMode = (nextMode: OrgMode) => {
    setMode(nextMode);
    setSelectedUnit(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenUnit = (targetMode: OrgMode, unitIndex: number) => {
    setMode(targetMode);
    setSelectedUnit(unitIndex);
    setTimeout(() => {
      scrollToSection('sec-detail');
    }, 60);
  };

  const handleSelectUnitFromCurrent = (unitIndex: number | null) => {
    setSelectedUnit(unitIndex);
    if (unitIndex !== null) {
      setTimeout(() => {
        scrollToSection('sec-detail');
      }, 60);
    } else {
      setTimeout(() => {
        scrollToSection('sec-prog');
      }, 60);
    }
  };

  const handleGoActivity = () => {
    if (mode !== 'osis') {
      setMode('osis');
      setSelectedUnit(null);
    }
    setTimeout(() => {
      scrollToSection('sec-act');
    }, 60);
  };

  useEffect(() => {
    const ids = ['sec-home', 'sec-visi', 'sec-misi', 'sec-org', 'sec-prog'];
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        }
      },
      { rootMargin: '-25% 0px -55% 0px', threshold: 0.01 }
    );

    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [mode]);

  return (
    <div className={`min-h-screen bg-white text-slate-900 ${mode === 'osis' ? 'theme-osis' : 'theme-mpk'}`}>
      <Header
        mode={mode}
        activeSection={activeSection}
        onNavigateSection={scrollToSection}
        onOpenUnit={handleOpenUnit}
        onGoActivity={handleGoActivity}
      />

      <main>
        <HeroSection
          profile={profile}
          mode={mode}
          onSelectMode={handleSelectMode}
        />

        <AboutSection profile={profile} mode={mode} />

        <StructureSection
          profile={profile}
          mode={mode}
          onSelectUnit={(idx) => handleSelectUnitFromCurrent(idx)}
        />

        <ProgramsSection
          profile={profile}
          mode={mode}
          selectedUnit={selectedUnit}
          onSelectUnit={handleSelectUnitFromCurrent}
        />

        <ActivityAndContactSection
          profile={profile}
          mode={mode}
          onScrollHome={() => scrollToSection('sec-home')}
        />
      </main>
    </div>
  );
}
